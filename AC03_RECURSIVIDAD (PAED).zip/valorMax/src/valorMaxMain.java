import java.util.Scanner;

public class valorMaxMain {

    public static int maxValue(int[] array, int tamano) {

        int max = 0;
        if (tamano != (array.length)) {
            max = Math.max(array[tamano], maxValue(array, tamano + 1));
        }
        return max;
    }


    public static void main(String[] args) {


        int[] array = {1, 5, 252, 24, 7, 82, 3};

        System.out.println("Numero mas grande es: " + maxValue(array, 0));
    }
}
