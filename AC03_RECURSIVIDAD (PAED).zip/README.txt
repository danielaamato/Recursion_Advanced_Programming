/*
1. Para el primer ejercicio (sumaBin), he usado matagalls para implementarlo con lenguaje C. El codigo esta creado para
que el usuario introduzca por teclado el numero que quiera. Se pedira el numero por pantalla del cual quiere recibir el
resultado de la potencia. Quiero aclarar que para el codigo se ha usado floats en vez de ints ya que con enteros y potencias de numeros tan grandes no es suficiente el rango de numeros que cubren.

2. Para el segundo ejercicio (digitsCreixent), he usado matagalls tambien implementado con lenguaje C. 
Esta creado tambien de forma que el usuario introduzca el numero por teclado y le dira por pantalla si esta ordenado o no.

3. Para el tercer ejercicio (valorMaxim), he usado IntelliJ Idea usando como lenguaje Java. 
Habra que definir previamente los numeros que queremos que contenga el array sin importar cuantos. 
Actualmente el array contiene los numeros del ejemplo del enunciado

*/