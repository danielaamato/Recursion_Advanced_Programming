#include <stdio.h>

int digitsCrec (int n) {
    int temp;
       
    if (n < 10) {
        return 1;
    }
    
    temp = n % 10 - digitsCrec(n / 10);
    
    return temp;
}

int main() {
    int num;
    int func;
    
    printf("Type your number: ");
    scanf ("%d", &num);
    
    if (num >= 0) {
        func = digitsCrec(num);
    }
    else {
        printf ("\nTu numero no es positvo\n");
    }
    
    if (func > 1) {
        printf("\nLos digitos de tu numero estan ordenados de mayor a menor\n");
    }
    else {
        printf("\nLos digitos de tu numero no estan ordenado de mayor a menor\n");
    }
    return 0;
}

