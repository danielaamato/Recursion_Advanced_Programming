#include <stdio.h>
#include <math.h>

float sumaBin (int n) {
        
    if (n == 0 || n == 1) {
        return 1;
    }
    
    float temp = pow(2, n) - sumaBin(n/2 - 1);
    return temp;
}

int main() {
    float num;
    float fact;
    
    printf("Type your number: ");
    scanf ("%f", &num);
    
    if (num >= 0) {
        fact = sumaBin(num);
        printf ("%.0f", fact);
    }
    else {
        printf ("\nYour number is not positive\n");
    }
    return 0;
}




